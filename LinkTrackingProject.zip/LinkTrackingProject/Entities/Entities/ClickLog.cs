﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Entities
{
    public class ClickLog
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string ShortCode { get; set; }
        public string IPAddress { get; set; }
        public string? Country { get; set; }
        public string? Region { get; set; }
        public string? City { get; set; }
        public string? Browser { get; set; }
        public string? OS { get; set; }
        public string? Referer { get; set; }
        public DateTime VisitedAt { get; set; } = DateTime.UtcNow;
        public ShortLink ShortLink { get; set; }

    }
}
